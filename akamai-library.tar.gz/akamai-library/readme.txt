Scripts placed in this directory can be called by Alerts for execution
